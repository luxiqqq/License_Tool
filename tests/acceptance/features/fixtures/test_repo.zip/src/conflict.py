
# SPDX-License-Identifier: GPL-3.0
# This file forces a copyleft license which conflicts with MIT main license.
def conflict():
    print("I am INCOMPATIBLE with the main license")
