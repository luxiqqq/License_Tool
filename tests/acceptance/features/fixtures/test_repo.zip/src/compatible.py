
# SPDX-License-Identifier: MIT
def ok():
    print("I am compatible with the main license (MIT)")
