# Test Project
Questa è una repository di test per il License Checker.
Serve a verificare la funzionalità di upload dei file zip.
