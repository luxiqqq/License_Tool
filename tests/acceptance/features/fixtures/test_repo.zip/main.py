
def main():
    print("Hello form the test zip!")

if __name__ == "__main__":
    main()
